package learn.aws.springbootdockerimage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDockerImageApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDockerImageApplication.class, args);
	}

}
