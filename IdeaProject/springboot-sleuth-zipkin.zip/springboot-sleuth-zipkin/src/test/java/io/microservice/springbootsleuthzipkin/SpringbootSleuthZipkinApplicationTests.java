package io.microservice.springbootsleuthzipkin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootSleuthZipkinApplicationTests {

	@Test
	void contextLoads() {
	}

}
