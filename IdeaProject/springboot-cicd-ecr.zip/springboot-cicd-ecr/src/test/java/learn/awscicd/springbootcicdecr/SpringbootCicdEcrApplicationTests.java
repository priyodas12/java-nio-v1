package learn.awscicd.springbootcicdecr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCicdEcrApplicationTests {

	@Test
	void contextLoads() {
	}

}
