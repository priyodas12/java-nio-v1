package labs.codecommit.awscicdspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsCicdSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsCicdSpringbootApplication.class, args);
	}

}
